import os
import selenium
import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import pandas as pd
from dateutil.parser import parse
from bs4 import BeautifulSoup
import re
import math
import requests
from urllib.request import urlretrieve
import pandas as pd
import concurrent.futures
from sqlalchemy import create_engine
import psycopg2

# Getting main page table data
all_page_url = []
driver = webdriver.Chrome(r'C:\Users\Dell 2\chromedriver_win32\chromedriver.exe')

def main_page_year_selection():
    for i in range(1, 2):

        driver.refresh()
        driver.get("http://delhihighcourt.nic.in/case.asp")
        driver.maximize_window()
        time.sleep(5)

        # selecting year
        driver.find_element_by_xpath(
            '/html/body/div[1]/div/article/div/div[2]/form[4]/select/option[' + str(i) + ']').click()
        time.sleep(5)

        # capturing year
        year = driver.find_element_by_xpath(
            '/html/body/div[1]/div/article/div/div[2]/form[4]/select/option[' + str(i) + ']').text
        print('year', year)

        # getting key
        key = driver.find_element_by_xpath('//*[@id="InnerPageContent"]/form[1]/label[4]')
        key = re.findall(r'[0-9]+', key.text)[0]

        # passing key
        inputkey = driver.find_element_by_xpath('/html/body/div[1]/div/article/div/div[2]/form[4]/input[2]')
        inputkey.send_keys(key)
        time.sleep(5)

        # clicking on display
        driver.find_element_by_xpath('//*[@id="InnerPageContent"]/form[4]/button').click()
        time.sleep(15)

        pno = driver.find_element_by_xpath('/html/body/div[1]/div/article/div/div[2]/span')

        total_pages = math.ceil((int(pno.text.split(':')[-1].strip()) / 8))
        print('total_pages', total_pages)

        # for total pages give total_pages in range
        for pi in range(0, 10):
            page_no = pi * 8

            page = 'http://delhihighcourt.nic.in/dhc_case_status_list_new.asp?ayear=&pyear=&SNo=4&SRecNo=' + str(
                page_no) + '&dno=&dyear=' + str(year) + '&ctype_29=&cno=&cyear=&party=&adv='
            url_list = {'page_url': page}
            all_page_url.append(url_list)
    df = pd.DataFrame(all_page_url)
    return df

df = main_page_year_selection()
# df.to_excel('page_urls.xlsx', index=False)


#if want to pass page urls creating manually we can do without selenium
# df = pd.read_excel('urls_list1.xlsx')[0:50]

# To get the individual page table data
def get_table_data(record):
    table_data = []
    resp = requests.get(record.get('page_url'))
    jsoup = BeautifulSoup(resp.content)
    table = jsoup.find('div', attrs={'id': 'InnerPageContent'})
    ul = table.find('ul')
    if ul:
        for li in ul.find_all('li'):
            dummy = dict()

            span = [span for span in li.find_all('span')]
            if len(span) == 4:
                button = span[1].find('button')
                petition_link = 'http://delhihighcourt.nic.in/' + button.attrs.get('onclick').split("'")[1].split("'")[
                    0] if button else button

                petition_number = petition_link.split('pno=')[-1].replace("'", '') if petition_link else None

                dummy['Petition_Number'] = petition_number
                dummy['Petition_Link'] = petition_link

                diary_case_no_status = re.sub(r'[^\x00-\x7F]', '', span[1].text)
                diary_case_no_status = [k.strip() for k in diary_case_no_status.strip().split('\n') if
                                        len(k.strip()) != 0]
                if len(diary_case_no_status) == 3:
                    if re.search('[a-zA-Z]', diary_case_no_status[0]):
                        dummy['DairyNo'] = None
                        dummy['CaseNo'] = diary_case_no_status[0]
                        dummy['Status'] = re.sub('\[|\]', '', diary_case_no_status[1])
                    else:
                        dummy['DairyNo'] = diary_case_no_status[0]
                        dummy['CaseNo'] = diary_case_no_status[1]
                        dummy['Status'] = re.sub('\[|\]', '', diary_case_no_status[2])
                elif len(diary_case_no_status) == 2:
                    dummy['DairyNo'] = None
                    dummy['CaseNo'] = diary_case_no_status[0]
                    dummy['Status'] = re.sub('\[|\]', '', diary_case_no_status[1])

                petitioner_vs_respondent = span[2].text.strip()
                petitioner_vs_respondent = re.sub(' +|\s', ' ', petitioner_vs_respondent)
                petitioner_vs_respondent = ' '.join(petitioner_vs_respondent.split('\n'))

                advocate = re.search('Advocate[\s:]+(.+)', petitioner_vs_respondent)
                advocate = advocate.group(1) if advocate else advocate
                dummy['advocate'] = advocate

                petitioner_vs_respondent = re.sub('Advocate[\s:]+(.+)', '', petitioner_vs_respondent)
                petitioner_vs_respondent = re.split('Vs.', petitioner_vs_respondent, re.I)

                if len(petitioner_vs_respondent) == 2:
                    dummy['petitioner'] = petitioner_vs_respondent[0].strip()
                    dummy['respondent'] = petitioner_vs_respondent[1].strip()

                listing_date_court_no = span[3].text.replace('\n', '').strip()

                ldate = re.search('\d{,2}/\d{,2}/\d{,4}', listing_date_court_no)

                ldate = ldate.group(0) if ldate else ldate
                dummy['last_date'] = ldate
                cno = re.search('Court No[\. :]+(.*)', listing_date_court_no)
                cno = cno.group(1) if cno else cno
                dummy['court_no'] = cno
                dummy['page_url'] = record.get('page_url')

                table_data.append(dummy)

    return table_data


records = df.to_dict(orient='records')[0:50]
fuldata = []
with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
    future_to_url = {executor.submit(get_table_data, record): record for record in records}
    for future in concurrent.futures.as_completed(future_to_url):
        url = future_to_url[future]
        try:
            data = future.result()
        except Exception as exc:
            print('%r generated an exception: %s' % (url, exc))
        else:
            print('extracting')
            if data:
                fuldata.extend(data)

df1 = pd.DataFrame(fuldata)
# df1.to_excel('fuldata.xlsx', index=False)

# pdf  files page details extraction
def get_pdf_page_details(record):
    page = requests.get(record.get('Petition_Link')).content
    soup = BeautifulSoup(page, 'html.parser')

    ul = soup.find('div', {'class': 'inner-page-content'})
    ul = ul if ul else ul

    ull = ul.find('div', {'class': 'notifi'})
    ull = ull if ul else ull

    pdf_page_link = ull.find('button').attrs.get('onclick')
    pdf_page_link = 'http://delhihighcourt.nic.in/' + pdf_page_link.split("'")[1].split("'")[
        0] if pdf_page_link else pdf_page_link

    pdf_info = {'pdf_page_link': pdf_page_link, 'Petition_Number': record.get('Petition_Number')}

    return pdf_info


no_pdf_url = []
# records = pd.read_excel('fuldata.xlsx').to_dict(orient='records')
records = df1.to_dict(orient='records')
fuldata = []
with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
    future_to_url = {executor.submit(get_pdf_page_details, record): record for record in records}
    for future in concurrent.futures.as_completed(future_to_url):
        url = future_to_url[future]

        try:
            data = future.result()
        except Exception as exc:

            no_pdf = {'failed urls': url.get('page_url')}
            no_pdf_url.append(no_pdf)

        #             print('%r generated an exception: %s' % (url, exc))
        else:
            print('extracting')
            if data:
                fuldata.append(data)

no_pdf_url = pd.DataFrame(no_pdf_url)
no_pdf_url.to_excel('C:\\Users\\Dell 2\\Desktop\\no_pdf_urls.xlsx', index=False)

df2 = pd.DataFrame(fuldata)
# df2.to_excel('pdf_data.xlsx', index=False)

def get_pdf_links(record):
    page = requests.get(record.get('pdf_page_link')).content
    soup = BeautifulSoup(page, 'html.parser')
    ul = soup.find('ul', {'class': 'clearfix grid last'})

    all_pdf_links = []

    for i1 in ul.find_all('li'):
        pdf_name = i1.find('button', {'class': 'LongCaseNoBtn'})
        pdf_name = pdf_name.text if pdf_name else pdf_name

        pdf_link = i1.find('button', {'class': 'LongCaseNoBtn'})
        pdf_link = pdf_link.attrs.get('onclick').split("'")[1].split("'")[0] if pdf_link else pdf_link

        Date_of_Order = i1.find('span', {'class': re.compile("pull-left width-30 title")})
        Date_of_Order = Date_of_Order.text if Date_of_Order else Date_of_Order

        pdf_link_info = {'Date_of_Order': Date_of_Order, 'pdf_name': pdf_name,
                         'pdf_link': pdf_link, 'Petition_Number': record.get('Petition_Number'),
                         'pdf_page_link': record.get('pdf_page_link')}
        all_pdf_links.append(pdf_link_info)
    return all_pdf_links


# records = pd.read_excel('pdf_data.xlsx').to_dict(orient='records')[0:1]
records = df2.to_dict(orient='records')[0:10]
fuldata = []
with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
    future_to_url = {executor.submit(get_pdf_links, record): record for record in records}
    for future in concurrent.futures.as_completed(future_to_url):
        url = future_to_url[future]
        try:
            data = future.result()
        except Exception as exc:
            print('%r generated an exception: %s' % (url, exc))
        else:
            print('extracting')
            if data:
                fuldata.extend(data)
df3 = pd.DataFrame(fuldata)
# df3.to_excel('pdf_links.xlsx', index=False)

# downloading pdf files
def get_pdf_download(record):
    Petition_Number = record.get('Petition_Number')
    resp = requests.get(record.get('pdf_link'))
    jsoup = BeautifulSoup(resp.content)
    iframe = jsoup.find('iframe')
    if iframe:
        pdf_actual_link = iframe.attrs.get('src')
        pdf_no = pdf_actual_link.split('/')[-1].split('.')[0]

        if not os.path.exists(str(Petition_Number)):
            os.makedirs(str(Petition_Number))
        urlretrieve(pdf_actual_link, str(Petition_Number) + "\\" + str(pdf_no) + ".pdf")

        pdf_info = {'pdf_no': pdf_no, 'pdf_actual_link': pdf_actual_link, 'Petition_Number': Petition_Number,
                    'Date_of_Order': record.get('Date_of_Order'), 'pdf_name': record.get('pdf_name'),
                    'pdf_page_link': record.get('pdf_page_link')}

        return pdf_info


# records = pd.read_excel('pdf_data.xlsx').to_dict(orient='records')[0:1]
records = df3.to_dict(orient='records')[45:60]
fuldata = []
with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
    future_to_url = {executor.submit(get_pdf_download, record): record for record in records}
    for future in concurrent.futures.as_completed(future_to_url):
        url = future_to_url[future]
        try:
            data = future.result()
        except Exception as exc:
            print('%r generated an exception: %s' % (url, exc))
        else:
            print('extracting')
            if data:
                fuldata.append(data)
df4 = pd.DataFrame(fuldata)
# df4.to_excel('pdf_final_data4.xlsx', index=False)

# uploading data to MySQL
engine = create_engine('mysql+pymysql://root:sai45678@localhost:3306/advarisk?charset=utf8')

df1[["Petition_Number",'Petition_Link','DairyNo','CaseNo','Status','advocate','petitioner','respondent','last_date','court_no','page_url']].to_sql('status_of_cases', engine, if_exists='append',index=False,schema='AdvaRisk')
#df4 storing table data
# df4[['pdf_no','pdf_actual_link','Petition Number',"Date_of_Order",'pdf_name','pdf_page_link']].to_sql('pdf_data', engine, if_exists='append',index=False,schema='AdvaRisk')

df4 = str([tuple(prod) for prod in df4.values]).strip('[]')
# using (ON DUPLICATE KEY UPDATE) updaing the values
sql_update = "INSERT into pdf_data (pdf_no, pdf_actual_link, Petition_Number, Date_of_Order, pdf_name, pdf_page_link) VALUES " + df4 + " ON DUPLICATE KEY UPDATE pdf_actual_link=VALUES(pdf_actual_link), Petition_Number=VALUES(Petition_Number), Date_of_Order=VALUES(Date_of_Order), pdf_name=VALUES(pdf_name), pdf_page_link=VALUES(pdf_page_link)"
engine.execute(sql_update)
print('completed')